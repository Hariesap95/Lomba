// Digital Signature Functionality for Competition Scoring System

class SignaturePad {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.isDrawing = false;
        this.lastX = 0;
        this.lastY = 0;
        this.canvasId = canvasId;
        
        this.setupCanvas();
        this.bindEvents();
    }
    
    setupCanvas() {
        // Set canvas size
        const rect = this.canvas.getBoundingClientRect();
        this.canvas.width = rect.width;
        this.canvas.height = rect.height;
        
        // Set drawing styles
        this.ctx.strokeStyle = '#000000';
        this.ctx.lineWidth = 2;
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';
        
        // Fill with white background
        this.ctx.fillStyle = '#ffffff';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    }
    
    bindEvents() {
        // Mouse events
        this.canvas.addEventListener('mousedown', this.startDrawing.bind(this));
        this.canvas.addEventListener('mousemove', this.draw.bind(this));
        this.canvas.addEventListener('mouseup', this.stopDrawing.bind(this));
        this.canvas.addEventListener('mouseout', this.stopDrawing.bind(this));
        
        // Touch events for mobile
        this.canvas.addEventListener('touchstart', this.handleTouch.bind(this));
        this.canvas.addEventListener('touchmove', this.handleTouch.bind(this));
        this.canvas.addEventListener('touchend', this.stopDrawing.bind(this));
        
        // Prevent scrolling when drawing on touch devices
        this.canvas.addEventListener('touchstart', (e) => e.preventDefault());
        this.canvas.addEventListener('touchend', (e) => e.preventDefault());
        this.canvas.addEventListener('touchmove', (e) => e.preventDefault());
    }
    
    getMousePos(e) {
        const rect = this.canvas.getBoundingClientRect();
        return {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };
    }
    
    getTouchPos(e) {
        const rect = this.canvas.getBoundingClientRect();
        return {
            x: e.touches[0].clientX - rect.left,
            y: e.touches[0].clientY - rect.top
        };
    }
    
    startDrawing(e) {
        this.isDrawing = true;
        const pos = this.getMousePos(e);
        this.lastX = pos.x;
        this.lastY = pos.y;
        
        // Start a new path
        this.ctx.beginPath();
        this.ctx.moveTo(this.lastX, this.lastY);
    }
    
    draw(e) {
        if (!this.isDrawing) return;
        
        const pos = this.getMousePos(e);
        
        this.ctx.lineTo(pos.x, pos.y);
        this.ctx.stroke();
        
        this.lastX = pos.x;
        this.lastY = pos.y;
        
        // Update the hidden input with signature data
        this.updateSignatureData();
    }
    
    stopDrawing() {
        if (!this.isDrawing) return;
        this.isDrawing = false;
        this.ctx.beginPath();
    }
    
    handleTouch(e) {
        e.preventDefault();
        
        const touch = e.touches[0];
        const mouseEvent = new MouseEvent(e.type === 'touchstart' ? 'mousedown' : 
                                        e.type === 'touchmove' ? 'mousemove' : 'mouseup', {
            clientX: touch.clientX,
            clientY: touch.clientY
        });
        
        this.canvas.dispatchEvent(mouseEvent);
    }
    
    clear() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        // Fill with white background
        this.ctx.fillStyle = '#ffffff';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Clear the hidden input
        this.updateSignatureData();
    }
    
    isEmpty() {
        // Check if canvas is empty (only white pixels)
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imageData.data;
        
        for (let i = 0; i < data.length; i += 4) {
            // Check if pixel is not white
            if (data[i] !== 255 || data[i + 1] !== 255 || data[i + 2] !== 255) {
                return false;
            }
        }
        return true;
    }
    
    getSignatureData() {
        if (this.isEmpty()) {
            return '';
        }
        return this.canvas.toDataURL('image/png');
    }
    
    updateSignatureData() {
        const hiddenInput = document.getElementById(this.canvasId + '-data');
        if (hiddenInput) {
            hiddenInput.value = this.getSignatureData();
        }
    }
    
    loadSignature(dataUrl) {
        if (!dataUrl) return;
        
        const img = new Image();
        img.onload = () => {
            this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
            this.ctx.fillStyle = '#ffffff';
            this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
            this.ctx.drawImage(img, 0, 0, this.canvas.width, this.canvas.height);
            this.updateSignatureData();
        };
        img.src = dataUrl;
    }
}

// Global signature pad instances
const signaturePads = {};

// Initialize signature pad
function initializeSignaturePad(canvasId) {
    if (document.getElementById(canvasId)) {
        signaturePads[canvasId] = new SignaturePad(canvasId);
        console.log(`Signature pad initialized for ${canvasId}`);
    }
}

// Clear signature pad
function clearSignature(canvasId) {
    if (signaturePads[canvasId]) {
        signaturePads[canvasId].clear();
        console.log(`Signature cleared for ${canvasId}`);
    }
}

// Get signature data
function getSignatureData(canvasId) {
    if (signaturePads[canvasId]) {
        return signaturePads[canvasId].getSignatureData();
    }
    return '';
}

// Check if signature is empty
function isSignatureEmpty(canvasId) {
    if (signaturePads[canvasId]) {
        return signaturePads[canvasId].isEmpty();
    }
    return true;
}

// Load signature from data URL
function loadSignature(canvasId, dataUrl) {
    if (signaturePads[canvasId]) {
        signaturePads[canvasId].loadSignature(dataUrl);
    }
}

// Validate all signatures on form
function validateSignatures() {
    const requiredSignatures = ['judge-signature', 'participant-signature'];
    const missingSignatures = [];
    
    requiredSignatures.forEach(canvasId => {
        if (document.getElementById(canvasId) && isSignatureEmpty(canvasId)) {
            missingSignatures.push(canvasId.replace('-', ' '));
        }
    });
    
    if (missingSignatures.length > 0) {
        alert(`Please provide the following signatures: ${missingSignatures.join(', ')}`);
        return false;
    }
    
    return true;
}

// Auto-resize canvas on window resize
function resizeSignaturePads() {
    Object.keys(signaturePads).forEach(canvasId => {
        const canvas = document.getElementById(canvasId);
        if (canvas) {
            const signatureData = signaturePads[canvasId].getSignatureData();
            signaturePads[canvasId].setupCanvas();
            if (signatureData) {
                signaturePads[canvasId].loadSignature(signatureData);
            }
        }
    });
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Auto-initialize signature pads
    const signatureCanvases = document.querySelectorAll('.signature-pad');
    signatureCanvases.forEach(canvas => {
        initializeSignaturePad(canvas.id);
    });
});

// Handle window resize
let resizeTimeout;
window.addEventListener('resize', function() {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(resizeSignaturePads, 250);
});

// Export functions for global use
window.initializeSignaturePad = initializeSignaturePad;
window.clearSignature = clearSignature;
window.getSignatureData = getSignatureData;
window.isSignatureEmpty = isSignatureEmpty;
window.loadSignature = loadSignature;
window.validateSignatures = validateSignatures;
