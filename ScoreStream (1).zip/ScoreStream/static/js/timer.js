// Timer functionality for Competition Scoring System

class CompetitionTimer {
    constructor(scoreId, duration) {
        this.scoreId = scoreId;
        this.duration = duration; // in seconds
        this.remaining = duration;
        this.interval = null;
        this.isRunning = false;
        this.callbacks = {
            onTick: null,
            onWarning: null,
            onExpired: null,
            onComplete: null
        };
        
        this.warningThreshold = Math.max(60, duration * 0.2); // 20% or 60 seconds, whichever is greater
        this.dangerThreshold = Math.max(30, duration * 0.1);  // 10% or 30 seconds, whichever is greater
    }
    
    start() {
        if (this.isRunning) return;
        
        this.isRunning = true;
        this.updateDisplay();
        
        this.interval = setInterval(() => {
            this.remaining--;
            this.updateDisplay();
            
            // Trigger callbacks
            if (this.callbacks.onTick) {
                this.callbacks.onTick(this.remaining);
            }
            
            if (this.remaining <= this.dangerThreshold && this.callbacks.onWarning) {
                this.callbacks.onWarning(this.remaining, 'danger');
            } else if (this.remaining <= this.warningThreshold && this.callbacks.onWarning) {
                this.callbacks.onWarning(this.remaining, 'warning');
            }
            
            if (this.remaining <= 0) {
                this.stop();
                if (this.callbacks.onExpired) {
                    this.callbacks.onExpired();
                }
            }
        }, 1000);
    }
    
    stop() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
        this.isRunning = false;
        
        if (this.callbacks.onComplete) {
            this.callbacks.onComplete();
        }
    }
    
    reset() {
        this.stop();
        this.remaining = this.duration;
        this.updateDisplay();
    }
    
    formatTime(seconds) {
        const minutes = Math.floor(Math.abs(seconds) / 60);
        const secs = Math.abs(seconds) % 60;
        const sign = seconds < 0 ? '-' : '';
        return `${sign}${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    
    updateDisplay() {
        const displayElement = document.getElementById('timer-display');
        if (displayElement) {
            displayElement.textContent = this.formatTime(this.remaining);
            
            // Update display classes based on remaining time
            displayElement.classList.remove('warning', 'danger');
            
            if (this.remaining <= 0) {
                displayElement.classList.add('danger');
                displayElement.textContent = 'TIME UP!';
            } else if (this.remaining <= this.dangerThreshold) {
                displayElement.classList.add('danger');
            } else if (this.remaining <= this.warningThreshold) {
                displayElement.classList.add('warning');
            }
        }
    }
    
    setCallback(event, callback) {
        if (this.callbacks.hasOwnProperty(event)) {
            this.callbacks[event] = callback;
        }
    }
    
    getProgress() {
        return Math.max(0, (this.duration - this.remaining) / this.duration);
    }
    
    getRemaining() {
        return this.remaining;
    }
    
    isExpired() {
        return this.remaining <= 0;
    }
}

// Global timer instance
let competitionTimer = null;

// Start timer for a specific score
function startTimer(scoreId, duration) {
    // First check server status
    checkTimerStatus(scoreId)
        .then(status => {
            if (status.started) {
                const elapsed = duration - status.remaining;
                competitionTimer = new CompetitionTimer(scoreId, duration);
                competitionTimer.remaining = Math.max(0, status.remaining);
                
                // Set up callbacks
                competitionTimer.setCallback('onWarning', (remaining, level) => {
                    showTimerWarning(remaining, level);
                });
                
                competitionTimer.setCallback('onExpired', () => {
                    handleTimerExpired();
                });
                
                competitionTimer.start();
            } else {
                console.log('Timer not started on server');
            }
        })
        .catch(error => {
            console.error('Failed to check timer status:', error);
        });
}

// Check timer status from server
function checkTimerStatus(scoreId) {
    return fetch(`/api/timer_status/${scoreId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            return data;
        });
}

// Show timer warnings
function showTimerWarning(remaining, level) {
    const warningElement = document.getElementById('timer-warning');
    if (warningElement) {
        warningElement.textContent = `Warning: ${Math.floor(remaining / 60)}:${(remaining % 60).toString().padStart(2, '0')} remaining`;
        warningElement.className = `alert alert-${level === 'danger' ? 'danger' : 'warning'}`;
        warningElement.style.display = 'block';
    }
    
    // Play warning sound if available
    if (level === 'danger') {
        playWarningSound();
    }
}

// Handle timer expiration
function handleTimerExpired() {
    // Show modal or alert
    showTimerExpiredModal();
    
    // Disable form submission if timer expired
    const scoringForm = document.getElementById('scoring-form');
    if (scoringForm) {
        const submitButton = scoringForm.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.innerHTML = '<i data-feather="clock"></i> Time Expired';
        }
    }
    
    // Play alarm sound
    playAlarmSound();
}

// Show timer expired modal
function showTimerExpiredModal() {
    // Create modal if it doesn't exist
    let modal = document.getElementById('timerExpiredModal');
    if (!modal) {
        modal = createTimerExpiredModal();
        document.body.appendChild(modal);
    }
    
    // Show modal
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
}

// Create timer expired modal
function createTimerExpiredModal() {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = 'timerExpiredModal';
    modal.tabIndex = -1;
    modal.setAttribute('data-bs-backdrop', 'static');
    modal.setAttribute('data-bs-keyboard', 'false');
    
    modal.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">
                        <i data-feather="clock"></i> Time Expired
                    </h5>
                </div>
                <div class="modal-body text-center">
                    <div class="mb-3">
                        <i data-feather="alert-triangle" style="width: 64px; height: 64px;" class="text-danger"></i>
                    </div>
                    <h5>Scoring Time Has Expired</h5>
                    <p class="text-muted">
                        The allocated time for scoring this team has ended. 
                        Please complete your evaluation and submit your scores.
                    </p>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">
                        <i data-feather="check"></i> Understood
                    </button>
                </div>
            </div>
        </div>
    `;
    
    return modal;
}

// Play warning sound
function playWarningSound() {
    try {
        // Create audio context for short beep
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 800;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0, audioContext.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.01);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
        console.log('Audio not supported or blocked');
    }
}

// Play alarm sound
function playAlarmSound() {
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        
        // Create a more urgent alarm sound
        for (let i = 0; i < 3; i++) {
            setTimeout(() => {
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                
                oscillator.frequency.value = 1000;
                oscillator.type = 'square';
                
                gainNode.gain.setValueAtTime(0, audioContext.currentTime);
                gainNode.gain.linearRampToValueAtTime(0.2, audioContext.currentTime + 0.01);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
                
                oscillator.start(audioContext.currentTime);
                oscillator.stop(audioContext.currentTime + 0.3);
            }, i * 400);
        }
    } catch (error) {
        console.log('Audio not supported or blocked');
    }
}

// Create progress ring for timer
function createTimerProgressRing(remaining, total) {
    const progress = Math.max(0, remaining / total);
    const circumference = 2 * Math.PI * 25; // radius of 25
    const strokeDasharray = circumference;
    const strokeDashoffset = circumference * (1 - progress);
    
    return `
        <div class="progress-circle">
            <svg viewBox="0 0 60 60">
                <circle class="progress-ring" cx="30" cy="30" r="25"></circle>
                <circle class="progress-ring-fill" cx="30" cy="30" r="25" 
                        style="stroke-dasharray: ${strokeDasharray}; stroke-dashoffset: ${strokeDashoffset}"></circle>
                <text x="30" y="35" text-anchor="middle" fill="currentColor" font-size="12" font-weight="bold">
                    ${Math.ceil(remaining / 60)}m
                </text>
            </svg>
        </div>
    `;
}

// Stop current timer
function stopTimer() {
    if (competitionTimer) {
        competitionTimer.stop();
        competitionTimer = null;
    }
}

// Get timer status
function getTimerStatus() {
    if (competitionTimer) {
        return {
            isRunning: competitionTimer.isRunning,
            remaining: competitionTimer.remaining,
            isExpired: competitionTimer.isExpired(),
            progress: competitionTimer.getProgress()
        };
    }
    return null;
}

// Initialize timer display
function initializeTimerDisplay() {
    const timerContainer = document.getElementById('timer-container');
    if (timerContainer && !timerContainer.querySelector('#timer-warning')) {
        const warningDiv = document.createElement('div');
        warningDiv.id = 'timer-warning';
        warningDiv.className = 'alert mt-2';
        warningDiv.style.display = 'none';
        timerContainer.appendChild(warningDiv);
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    initializeTimerDisplay();
    
    // Re-initialize feather icons for modal content
    document.addEventListener('shown.bs.modal', function() {
        feather.replace();
    });
});

// Prevent accidental page reload when timer is running
window.addEventListener('beforeunload', function(e) {
    if (competitionTimer && competitionTimer.isRunning) {
        const confirmationMessage = 'Timer is still running. Are you sure you want to leave?';
        e.returnValue = confirmationMessage;
        return confirmationMessage;
    }
});

// Export functions for global use
window.startTimer = startTimer;
window.stopTimer = stopTimer;
window.getTimerStatus = getTimerStatus;
window.checkTimerStatus = checkTimerStatus;
